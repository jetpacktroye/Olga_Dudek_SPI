package com.example.olga_dudek_spi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlgaDudekSpiApplicationTests {

	@Test
	void contextLoads() {
	}

}
